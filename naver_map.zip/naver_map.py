import time
from selenium import webdriver
from selenium.webdriver.common.by import By # 웹엘리먼트 찾아주는 기능

class SeleniumConfig():
    driver = webdriver.Chrome()

    def Selenium_Close(self):
        self.driver.quit()
    
    def driver_find_element(self, by, element):
        return self.driver.find_element(by, element)

    def driver_find_element_click(self, by, element):
        return self.driver.find_element(by, element).click()
    
    def driver_send_text(self, by, element, contents):
        element = self.driver_find_element(by, element)
        element.send_keys(contents)
        
    
if __name__=='__main__':
    test=SeleniumConfig()
    test.driver.get('https://map.naver.com/p?c=11.00,0,0,0,dh')
    print(test.driver_find_element_click(By.CSS_SELECTOR, 'a.btn_navbar[href="/bus"]'))
    print(test.driver_find_element(By.CSS_SELECTOR, 'a.btn_navbar').get_attribute('innerText'))
    test.driver_send_text(By.CSS_SELECTOR, 'input[type="text"][role="combobox"]', '청량리역')
    time.sleep(600)
    